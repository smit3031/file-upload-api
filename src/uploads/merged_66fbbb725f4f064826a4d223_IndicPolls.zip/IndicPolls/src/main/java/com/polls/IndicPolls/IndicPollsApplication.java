package com.polls.IndicPolls;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndicPollsApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndicPollsApplication.class, args);
	}

}
